// Get DOM elements
const decryptBtn = document.querySelector('.decrypt-btn');
const messageContainer = document.querySelector('.message-container');
const heartContainer = document.querySelector('.heart-container');
const heartText = document.querySelector('.heart-text');

// Heart pattern - defines which positions should have text
const heartPattern = [
    "     111111         111111      ",
    "    1111111         1111111     ",
    "   11111111         11111111    ",
    "  111111111         111111111   ",
    "  111111111         111111111   ",
    " 1111111111         1111111111  ",
    " 1111111111         1111111111  ",
    "11111111111         11111111111 ",
    "11111111111         11111111111 ",
    "111111111111       111111111111 ",
    "111111111111       111111111111 ",
    " 11111111111     11111111111111 ",
    " 11111111111111111111111111111  ",
    "  1111111111111111111111111111  ",
    "  1111111111111111111111111111  ",
    "   111111111111111111111111111  ",
    "   111111111111111111111111111  ",
    "    11111111111111111111111111  ",
    "    11111111111111111111111111  ",
    "     1111111111111111111111111  ",
    "     1111111111111111111111111  ",
    "      111111111111111111111111  ",
    "      111111111111111111111111  ",
    "       11111111111111111111111  ",
    "       11111111111111111111111  ",
    "        1111111111111111111111  ",
    "        1111111111111111111111  ",
    "         111111111111111111111  ",
    "         111111111111111111111  ",
    "          11111111111111111111  ",
    "          11111111111111111111  ",
    "           1111111111111111111  ",
    "           1111111111111111111  ",
    "            111111111111111111  ",
    "            111111111111111111  ",
    "             11111111111111111  ",
    "             11111111111111111  ",
    "              1111111111111111  ",
    "              1111111111111111  ",
    "               111111111111111  ",
    "               111111111111111  ",
    "                11111111111111  ",
    "                11111111111111  ",
    "                 1111111111111  ",
    "                 1111111111111  ",
    "                  111111111111  ",
    "                  111111111111  ",
    "                   11111111111  ",
    "                   11111111111  ",
    "                    1111111111  ",
    "                    1111111111  ",
    "                     111111111  ",
    "                     111111111  ",
    "                      11111111  ",
    "                      11111111  ",
    "                       1111111  ",
    "                       1111111  ",
    "                        111111  ",
    "                        111111  ",
    "                         11111  ",
    "                         11111  ",
    "                          1111  ",
    "                          1111  ",
    "                           111  ",
    "                           111  ",
    "                            11  ",
    "                            11  ",
    "                             1  "
];

// Function to generate heart with text
function generateHeart() {
    heartText.innerHTML = '';
    heartText.style.position = 'fixed';
    heartText.style.width = '100vw';
    heartText.style.height = '100vh';
    heartText.style.top = '0';
    heartText.style.left = '0';
    heartText.style.pointerEvents = 'none';
    heartText.style.overflow = 'visible';
    
    // Create falling text elements
    for (let i = 0; i < 300; i++) {
        const span = document.createElement('span');
        
        // Co piąty element to serduszko zamiast tekstu
        if (i % 5 === 0) {
            span.textContent = '♡';
            span.style.fontSize = Math.random() * 20 + 12 + 'px';
        } else {
            span.textContent = 'i love you ';
            span.style.fontSize = Math.random() * 14 + 8 + 'px';
        }
        
        span.style.position = 'fixed';
        span.style.color = '#ff1744';
        span.style.whiteSpace = 'nowrap';
        span.style.fontWeight = '600';
        // Rozprzestrzeniaj na CAŁĄ szerokość - od -100px do width + 100px
        const randLeft = Math.random() * (window.innerWidth + 200) - 100;
        span.style.left = randLeft + 'px';
        span.style.top = (Math.random() * 200 - 100) + 'px';
        span.style.opacity = Math.random() * 0.7 + 0.3;
        span.style.zIndex = '50';
        
        // Random glow
        const glowStrength = Math.random() * 35 + 15;
        span.style.textShadow = `0 0 ${glowStrength}px rgba(255, 23, 68, ${Math.random() * 0.6 + 0.4})`;
        
        // Animation
        const duration = Math.random() * 4 + 5;
        const delay = Math.random() * 3;
        span.style.animation = `fall ${duration}s linear ${delay}s infinite`;
        
        heartText.appendChild(span);
    }
    
    // Add center text - NEON RED with flickering animation like fire
    const centerDiv = document.createElement('div');
    centerDiv.style.position = 'fixed';
    centerDiv.style.top = '50vh';
    centerDiv.style.left = '50vw';
    centerDiv.style.transform = 'translate(-50%, -50%)';
    centerDiv.style.fontSize = '52px';
    centerDiv.style.fontWeight = '700';
    centerDiv.style.color = '#ff1744';
    centerDiv.style.letterSpacing = '2px';
    centerDiv.style.zIndex = '100';
    centerDiv.style.whiteSpace = 'nowrap';
    centerDiv.style.pointerEvents = 'none';
    centerDiv.style.animation = 'neonFlicker 2s infinite';
    centerDiv.textContent = 'Love you.';
    
    heartText.appendChild(centerDiv);
    
    // Add sparks around the center text
    const sparkContainer = document.createElement('div');
    sparkContainer.style.position = 'fixed';
    sparkContainer.style.top = '50vh';
    sparkContainer.style.left = '50vw';
    sparkContainer.style.transform = 'translate(-50%, -50%)';
    sparkContainer.style.width = '200px';
    sparkContainer.style.height = '200px';
    sparkContainer.style.pointerEvents = 'none';
    sparkContainer.style.zIndex = '99';
    
    // Generate 20 sparks around the text
    for (let i = 0; i < 20; i++) {
        const spark = document.createElement('div');
        spark.style.position = 'absolute';
        
        // Random position in circle around text
        const angle = (i / 20) * Math.PI * 2 + (Math.random() - 0.5) * 0.5;
        const distance = 80 + Math.random() * 40;
        const x = Math.cos(angle) * distance;
        const y = Math.sin(angle) * distance;
        
        spark.style.left = (100 + x) + 'px';
        spark.style.top = (100 + y) + 'px';
        
        // Random size
        const size = Math.random() * 3 + 1;
        spark.style.width = size + 'px';
        spark.style.height = size + 'px';
        spark.style.borderRadius = '50%';
        
        // Red glow colors only
        const colors = ['#ff1744', '#ff4081', '#ff0040', '#ff3366'];
        const sparkColor = colors[Math.floor(Math.random() * colors.length)];
        spark.style.backgroundColor = sparkColor;
        spark.style.boxShadow = `0 0 ${size * 3}px ${sparkColor}`;
        
        // Random animation duration and delay
        const duration = Math.random() * 1.5 + 0.8;
        const delay = Math.random() * 2;
        spark.style.animation = `sparkle ${duration}s ease-in-out ${delay}s infinite`;
        
        sparkContainer.appendChild(spark);
    }
    
    heartText.appendChild(sparkContainer);
}

// Function to show heart
function showHeart() {
    messageContainer.classList.add('hidden');
    heartContainer.classList.remove('hidden');
    generateHeart();
    
    // Play background music
    playBackgroundMusic();
}

// Function to play background music
function playBackgroundMusic() {
    // Create or use existing audio
    if (!window.bgMusic) {
        window.bgMusic = new Audio();
        window.bgMusic.loop = true;
        window.bgMusic.volume = 0.4;
        // You can change this URL to any royalty-free music
        window.bgMusic.src = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';
    }
    window.bgMusic.play().catch(e => {
        // If URL doesn't work, try a fallback
        console.log('Playing background music...');
        // Generate simple tones using Web Audio API
        generateBeautifulTone();
    });
}

// Generate beautiful background tone
function generateBeautifulTone() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 528; // Love frequency
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 60);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 60);
    } catch (e) {
        console.log('Audio not available');
    }
}

// Add click events
decryptBtn.addEventListener('click', showHeart);
document.addEventListener('click', function(event) {
    // Only trigger if clicking on the page and heart isn't already shown
    if (!heartContainer.classList.contains('hidden')) return;
    showHeart();
});
